// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'angular-task-2349f',
    appId: '1:962220267699:web:75b38c0a73bf1a631ab8c6',
    storageBucket: 'angular-task-2349f.appspot.com',
    apiKey: 'AIzaSyBhE7GZ0_thaLzkcRTtoeULgwJZGumxFww',
    authDomain: 'angular-task-2349f.firebaseapp.com',
    messagingSenderId: '962220267699',
  },
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBhE7GZ0_thaLzkcRTtoeULgwJZGumxFww",
    authDomain: "angular-task-2349f.firebaseapp.com",
    projectId: "angular-task-2349f",
    storageBucket: "angular-task-2349f.appspot.com",
    messagingSenderId: "962220267699",
    appId: "1:962220267699:web:75b38c0a73bf1a631ab8c6"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
