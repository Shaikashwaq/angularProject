export const environment = {
  firebase: {
    projectId: 'angular-task-2349f',
    appId: '1:962220267699:web:75b38c0a73bf1a631ab8c6',
    storageBucket: 'angular-task-2349f.appspot.com',
    apiKey: 'AIzaSyBhE7GZ0_thaLzkcRTtoeULgwJZGumxFww',
    authDomain: 'angular-task-2349f.firebaseapp.com',
    messagingSenderId: '962220267699',
  },
  production: true
};
