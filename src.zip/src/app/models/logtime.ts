export interface logtime{
    id:string,
    pname:string,
    date:string,
    timework:string,
    role:string,
    desc:string
}